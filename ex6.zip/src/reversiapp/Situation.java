
package reversiapp;

/**
 * An enum to show the status of the game
 */
enum Situation {
    NoMovesForAll, ThereIsMove, NoMove
}